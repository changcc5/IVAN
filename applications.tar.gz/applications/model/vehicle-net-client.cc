/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright 2007 University of Washington
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include "ns3/log.h"
#include "ns3/ipv4-address.h"
#include "ns3/ipv6-address.h"
#include "ns3/nstime.h"
#include "ns3/inet-socket-address.h"
#include "ns3/inet6-socket-address.h"
#include "ns3/socket.h"
#include "ns3/simulator.h"
#include "ns3/socket-factory.h"
#include "ns3/packet.h"
#include "ns3/uinteger.h"
#include "ns3/trace-source-accessor.h"
#include "vehicle-net-client.h"
#include "ns3/random-variable-stream.h"
#include "ns3/mobility-model.h"
#include "ns3/double.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("VehicleNetClientApplication");

NS_OBJECT_ENSURE_REGISTERED (VehicleNetClient);

TypeId
VehicleNetClient::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::VehicleNetClient")
    .SetParent<Application> ()
    .SetGroupName("Applications")
    .AddConstructor<VehicleNetClient> ()
    .AddAttribute ("MaxPackets", 
                   "The maximum number of packets the application will send",
                   UintegerValue (100),
                   MakeUintegerAccessor (&VehicleNetClient::m_count),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("Interval", 
                   "The time to wait between packets",
                   TimeValue (Seconds (1.0)),
                   MakeTimeAccessor (&VehicleNetClient::m_interval),
                   MakeTimeChecker ())
    .AddAttribute ("RemoteAddress", 
                   "The destination Address of the outbound packets",
                   AddressValue (),
                   MakeAddressAccessor (&VehicleNetClient::m_peerAddress),
                   MakeAddressChecker ())
    .AddAttribute ("RemotePort", 
                   "The destination port of the outbound packets",
                   UintegerValue (0),
                   MakeUintegerAccessor (&VehicleNetClient::m_peerPort),
                   MakeUintegerChecker<uint16_t> ())
    .AddAttribute ("PacketSize", "Size of echo data in outbound packets",
                   UintegerValue (100),
                   MakeUintegerAccessor (&VehicleNetClient::SetDataSize,
                                         &VehicleNetClient::GetDataSize),
                   MakeUintegerChecker<uint32_t> ())
    .AddTraceSource ("Tx", "A new packet is created and is sent",
                     MakeTraceSourceAccessor (&VehicleNetClient::m_txTrace),
                     "ns3::Packet::TracedCallback")
  ;
  return tid;
}

VehicleNetClient::VehicleNetClient ()
{
  NS_LOG_FUNCTION (this);
  m_sent = 0;
  m_socket = 0;
  m_sendEvent = EventId ();
  m_data = 0;
  m_dataSize = 0;
  nodeid = 0;
}

VehicleNetClient::~VehicleNetClient()
{
  NS_LOG_FUNCTION (this);
  m_socket = 0;

  delete [] m_data;
  m_data = 0;
  m_dataSize = 0;
}

void 
VehicleNetClient::SetRemote (Address ip, uint16_t port)
{
  NS_LOG_FUNCTION (this << ip << port);
  m_peerAddress = ip;
  m_peerPort = port;
}

void 
VehicleNetClient::SetRemote (Ipv4Address ip, uint16_t port)
{
  NS_LOG_FUNCTION (this << ip << port);
  m_peerAddress = Address (ip);
  m_peerPort = port;
}

void 
VehicleNetClient::SetRemote (Ipv6Address ip, uint16_t port)
{
  NS_LOG_FUNCTION (this << ip << port);
  m_peerAddress = Address (ip);
  m_peerPort = port;
}

void
VehicleNetClient::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  Application::DoDispose ();
}

double
VehicleNetClient::GetRandom (double max)
{
double min = 0.000;
Ptr<UniformRandomVariable> x = CreateObject<UniformRandomVariable> ();
x->SetAttribute ("Min", DoubleValue (min));
x->SetAttribute ("Max", DoubleValue (max));
return x->GetValue ();
}
// push  cs and fib
void
VehicleNetClient::AddCs(uint16_t name, uint16_t data)
{
        int csSize = csNames.size ();
        bool csnamefound = false;
        for (int i = 0; i < csSize; i++)
        {
          uint16_t csname = csNames.front ();
          csNames.pop ();
          csNames.push(csname);
          if (csname == name)
          {
            csnamefound = true;
            break;
          }
        }
        if (!csnamefound)
        {
          csNames.push(name);
          csData.push(data);
        }
}

void
VehicleNetClient::AddPit(uint16_t name, uint16_t requester)
{
  std::queue<uint16_t> newpit;
  newpit.push(requester);
  pit[name] = newpit;
  //std::cout<< GetNode ()->GetId () << " has added " << name << " to pit." <<std::endl;
}
bool 
VehicleNetClient::UpdatePit(uint16_t name, uint16_t requester)
{
  pititer = pit.find(name);
  std::queue<uint16_t> pitentry = pititer->second;
  int size = pitentry.size();
  for (int i=0; i < size; i++)
  {
        uint16_t req = pitentry.front();
        pitentry.pop();
        pitentry.push(req);
        if (req == requester)
          return false;
  }
  pitentry.push(requester);
  return true;
}
bool
VehicleNetClient::RequestNameCheck(uint16_t name)
{
  int size = requestNames.size();
  for (int i = 0; i < size; i++)
  {
        uint16_t rname = requestNames.front();
        requestNames.pop();
        requestNames.push(rname);
        if (rname == name)
          return true;
  }
  return false;
}
bool
VehicleNetClient::SatisfyPit(uint16_t dname)
{
  int size = pitNames.size();
  for (int i = 0; i < size; i++)
  {
        uint16_t pitn = pitNames.front();
        pitNames.pop();
        if (dname == pitn)
          return true;
        pitNames.push(pitn);
  }
  return false;
}

// Send Advertise type, csName vector, and location in fib
void
VehicleNetClient::Advertise(void)
{
  int size = csNames.size();

  if (size > 0) 
  {
        // instantiate a packet
        Ptr<Packet> p = Create<Packet> ();
        // instantiate a header.
        ClientHeader header; // type
        header.SetData (1);
        ClientHeader count;
        count.SetData (size);
        for (int j = 0; j < size; j++ )
        {
          uint16_t csname = csNames.front();
          csNames.pop();
          csNames.push(csname);
          ClientHeader data;
          data.SetData (csname);
          Ptr<MobilityModel> model = GetNode()->GetObject<MobilityModel>();
          Vector position = model->GetPosition ();
          ClientHeader locX;
          locX.SetData (position.x);
          ClientHeader locY;
          locY.SetData (position.y);

          // and store my header into the packet.
          p->AddHeader (locY);
          p->AddHeader (locX);
          p->AddHeader (data);
          //std::cout<<GetNode()->GetId() << " advertise " << data.GetData() <<std::endl;
        }
        p->AddHeader (count);
        p->AddHeader (header);
        m_socket->Send (p);
        //std::cout<<Simulator::Now() << " " << GetNode () -> GetId() << " Advertize Sent"<<std::endl;
  }
  Simulator::Schedule (Seconds (1.5), &VehicleNetClient::Advertise, this);
}

void
VehicleNetClient::RequestInterest(uint16_t name, uint16_t req)
{
  ClientHeader type;
  type.SetData (2.); //type 2 request interest
  ClientHeader iname;
  iname.SetData (name);
  ClientHeader requester;
  requester.SetData (req);
  Ptr<Packet> p = Create<Packet> ();
  p->AddHeader (requester);
  p->AddHeader (iname);
  p->AddHeader (type);
  m_socket->Send (p);
  //std::cout << GetNode () -> GetId () << " has requested piece " << name << std::endl;
}

double
VehicleNetClient::GetDistance (double alocx, double alocy, double blocx, double blocy)
{
  return sqrt ((alocx-blocx) * (alocx - blocx) + (alocy - blocy) * (alocy - blocy));
}

double
VehicleNetClient::GetDistanceFromNode (double locx, double locy)
{
  Ptr<MobilityModel> model = GetNode()->GetObject<MobilityModel>();
  Vector position = model->GetPosition ();
  return GetDistance (position.x, position.y, locx, locy);
}
void
VehicleNetClient::SendInterest (uint16_t name)
{
  RequestInterest (name, GetNode()->GetId());
  if (!RequestNameCheck(name))
  {
    requestNames.push (name);
    reqTimes[name]= Simulator::Now ();
    //std::cout<< GetNode ()->GetId () << " has sent interest " << name << "." <<std::endl;
  }
  timeRequested = Simulator::Now ();
}

bool
VehicleNetClient::RespondDataCheck (uint16_t name)
{
  int ressize = respondData.size();
  for (int i = 0; i < ressize; i++)
  {
        uint16_t rname = respondData.front();
        respondData.pop();
        respondData.push(rname);
        if (rname == name)
          return true;
  }
  return false;
}

void
VehicleNetClient::fmRequestOdd (void)
{
  if (respondData.size () == 10 )
  {
        std::cout<< GetNode ()->GetId () << " has received every piece";
        for (int i = 0; i < 10; i++)
        {
          uint16_t name = i + 10;
          Time diff = respTimes[name] - reqTimes[name];
          std::cout<< " " << diff.GetMilliSeconds();
        }
        std::cout<< std::endl;
        //Simulator::Stop ();
  }
int fibsize = fibNames.size ();
//below is wrong: if not requested, will not be in fib:
//      not true: even if not requested, advertise should supply fib

  //int fiblsize = fibL.size();
  for (uint16_t i = 19; i > 9; i--)
  {
        bool foundfib = false;
        for (int j = 0; j < fibsize; j++)
        {
          uint16_t fname = fibNames.front ();
          fibNames.pop ();
          fibNames.push (fname);
          if (fname == i)
          {
                foundfib = true;
                break;
          }
        }
        if (!foundfib && !RespondDataCheck(i))
        {
          SendInterest (i);
 // std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " fiblsize " << fiblsize <<std::endl;
          Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestOdd, this);// only request new piece when received a piece
          return;
        }
        else if (foundfib && !RespondDataCheck(i))
        {
          uint16_t longestName = 0;
  uint16_t longestDist = 0;
  //int fiblsize = fibL.size();
  for (int i = 0; i < fibsize; i++)
  {
        uint16_t fibName = fibNames.front();
        fibNames.pop();
        Vector fibLoc = fibL.front();
        fibL.pop();
        double dist = GetDistanceFromNode (fibLoc.x, fibLoc.y);
        if (dist > longestDist && !RespondDataCheck(fibName))
        {
          longestName = fibName;
          longestDist = dist;
        }
        fibNames.push(fibName);
        fibL.push(fibLoc);
  }
  SendInterest (longestName);
 // std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " " << fiblsize <<std::endl;

  Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestOdd, this);
        return;
        }
  }

  // look in fib and request "rarest" by distance
/*
  uint16_t longestName = 0;
  uint16_t longestDist = 0;
  int fiblsize = fibL.size();
  for (int i = 0; i < fibsize; i++)
  {
        uint16_t fibName = fibNames.front();
        fibNames.pop();
        Vector fibLoc = fibL.front();
        fibL.pop();
        double dist = GetDistanceFromNode (fibLoc.x, fibLoc.y);
        if (dist > longestDist && !RespondDataCheck(fibName))
        {
          longestName = fibName;
          longestDist = dist;
        }
        fibNames.push(fibName);
        fibL.push(fibLoc);
  }
  SendInterest (longestName+2);
  std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " " << fiblsize <<std::endl;

  Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestEven, this);*/
}

void
VehicleNetClient::fmRequestEven (void)
{

  // if all pieces are present, then stop simulation && GetNode()->GetId() == 27
  if (respondData.size () == 10 )
  {
        std::cout<< GetNode ()->GetId () << " has received every piece";
        for (int i = 0; i < 10; i++)
        {
          uint16_t name = i + 10;
          Time diff = respTimes[name] - reqTimes[name];
          std::cout<< " " << diff.GetMilliSeconds();
        }
        std::cout<< std::endl;
        //Simulator::Stop ();
  }
  int fibsize = fibNames.size ();
//below is wrong: if not requested, will not be in fib:
//      not true: even if not requested, advertise should supply fib

 // int fiblsize = fibL.size();
  for (uint16_t i = 10; i < 20; i++)
  {
        bool foundfib = false;
        for (int j = 0; j < fibsize; j++)
        {
          uint16_t fname = fibNames.front ();
          fibNames.pop ();
          fibNames.push (fname);
          if (fname == i)
          {
                foundfib = true;
                break;
          }
        }
        if (!foundfib && !RespondDataCheck(i))
        {
          SendInterest (i);
  //std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " fiblsize " << fiblsize <<std::endl;
          Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestEven, this);// only request new piece when received a piece
          return;
        }
        else if (foundfib && !RespondDataCheck(i))
        {
          uint16_t longestName = 0;
  uint16_t longestDist = 0;
 // int fiblsize = fibL.size();
  for (int i = 0; i < fibsize; i++)
  {
        uint16_t fibName = fibNames.front();
        fibNames.pop();
        Vector fibLoc = fibL.front();
        fibL.pop();
        double dist = GetDistanceFromNode (fibLoc.x, fibLoc.y);
        if (dist > longestDist && !RespondDataCheck(fibName))
        {
          longestName = fibName;
          longestDist = dist;
        }
        fibNames.push(fibName);
        fibL.push(fibLoc);
  }
  SendInterest (longestName);
  //std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " " << fiblsize <<std::endl;

  Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestEven, this);
        return;
        }
  }

  // look in fib and request "rarest" by distance
/*
  uint16_t longestName = 0;
  uint16_t longestDist = 0;
  int fiblsize = fibL.size();
  for (int i = 0; i < fibsize; i++)
  {
        uint16_t fibName = fibNames.front();
        fibNames.pop();
        Vector fibLoc = fibL.front();
        fibL.pop();
        double dist = GetDistanceFromNode (fibLoc.x, fibLoc.y);
        if (dist > longestDist && !RespondDataCheck(fibName))
        {
          longestName = fibName;
          longestDist = dist;
        }
        fibNames.push(fibName);
        fibL.push(fibLoc);
  }
  SendInterest (longestName+2);
  std::cout << GetNode() -> GetId() << " fib size: "<<fibsize << " " << fiblsize <<std::endl;

  Simulator::Schedule (Seconds (0.5), &VehicleNetClient::fmRequestEven, this);*/
}
void
VehicleNetClient::RespondInterest(uint16_t name, uint16_t requester)
{
  //First check content store
  
  int cssize = csNames.size();
  for (int i = 0; i < cssize; i++)
  {
        uint16_t csname = csNames.front();
        uint16_t csdata = csData.front ();
        csData.pop ();
        csNames.pop();
        csNames.push(csname);
        csData.push(csdata);
        if (csname == name)
        {
          SendData (name, csdata);
          //std::cout<< GetNode ()->GetId () << " has found " << name << " in cs." <<std::endl;
          return;
        }
  }
  //if not then check Pit, forward interest
  bool pitchanged = false;
  pititer = pit.find(name);
  if (pititer != pit.end())
  {
        pitchanged = UpdatePit(name, requester);
  }
  else
  {
        AddPit(name, requester);
        pitchanged = true;
  }
if (pitchanged)
{
  //Finally check FIB broadcast broadcast delay depending on distance
  int fibsize = fibNames.size(); 
  for (int i = 0; i < fibsize; i++)
  {
        uint16_t fname = fibNames.front();
        fibNames.pop();
        Vector floc = fibL.front();
        fibL.pop();
        fibNames.push(fname);
        fibL.push(floc);
        if (fname == name)
        {
          double distance = GetDistanceFromNode(floc.x, floc.y);
          //std::cout<< GetNode ()->GetId () << " has found " << name << " in fib. Dist " <<distance <<std::endl;
          Simulator::Schedule (Seconds (1+distance/100), &VehicleNetClient::RequestInterest, this, name, requester);
        }
  }
}
}

void
VehicleNetClient::RespondData(uint16_t name, uint16_t data)
{
  //if is requester add to respond data queue and content store
        AddCs(name, data);
  if (RequestNameCheck(name))
  {
        //AddCs(name, data);
        if (!RespondDataCheck(name))
        {
          respondData.push(name);
          respTimes[name] = Simulator::Now ();
          //std::cout<<GetNode()->GetId() << " has received data requested " << name << std::endl;
        }
        return;
  }
  pititer = pit.find(name);
  if (pititer == pit.end())
  {
        pit.erase(name);
        //AddCs(name, data);
        SendData(name, data);
  }
  //check pit, if true, broadcast data and save to content store, forward data
/*
  int pitsize = pitNames.size ();
  bool pitfound = false;
  for (int i = 0; i < pitsize; i++)
  {
        uint16_t pname = pitNames.front();
        pitNames.pop();
        if (pname == name)
        {
          pitfound = true;
          //std::cout<< GetNode ()->GetId () << " has found " << name << " in pit." <<std::endl;
          break;
        }
        pitNames.push (pname);
  }
  if (pitfound)
  {
        int csSize = csNames.size ();
        bool csnamefound = false;
        for (int i = 0; i < csSize; i++)
        {
          uint16_t csname = csNames.front ();
          csNames.pop ();
          if (csname == name)
          {
            csnamefound = true;
            break;
          }
        }
        if (!csnamefound)
        {
          //std::cout<< GetNode ()->GetId () << " has added " << name << " in cs." <<std::endl;
          csNames.push (name);
          csData.push (data);
        }
        //std::cout << GetNode()->GetId() << " found data in pit " << name <<std::endl;
        SendData (name, data);
  }
*/
}

void
VehicleNetClient::SendData (uint16_t name, uint16_t csdata)
{
  ClientHeader dname, type, data;
  dname.SetData (name);
  type.SetData (3);
  data.SetData (csdata);
  Ptr<Packet> p = Create<Packet> ();
  p->AddHeader (data);
  p->AddHeader (dname);
  p->AddHeader (type);
  m_socket->Send (p);
  //std::cout<< GetNode ()->GetId () << " has sent data " << name <<std::endl;
}

// called after receiving an advertise: Checks if name exist in fib, add or update loc
void
VehicleNetClient::UpdateFib(uint16_t name, Vector loc)
{
  int size = fibNames.size();
  bool entryFound = false;
  for (int i = 0; i < size; i++)
  {
        uint16_t fibname = fibNames.front();
        fibNames.pop();
        Vector location = fibL.front();
        fibL.pop();
        if (fibname == name) {
          entryFound = true;
          fibNames.push(name);
          fibL.push(loc);
        }
        else {
          fibNames.push(fibname);
          fibL.push(location);
        }
        //std::cout<<Simulator::Now() << " " << GetNode () -> GetId() << " update fib"<<std::endl;
  }
  if (!entryFound) 
  {
        fibNames.push(name);
        fibL.push(loc);
        //std::cout<<Simulator::Now() << " " << GetNode () -> GetId() << " new fib " << name <<std::endl;
  }
}
void 
VehicleNetClient::StartApplication (void)
{
  nodeid = GetNode() -> GetId();
  NS_LOG_FUNCTION (this);
  //std::cout<<nodeid << " vehicle Started"<<std::endl;
  if (m_socket == 0)
    {
      TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
      m_socket = Socket::CreateSocket (GetNode (), tid);
      InetSocketAddress local = InetSocketAddress (Ipv4Address::GetAny (), m_peerPort);
      if (Ipv4Address::IsMatchingType(m_peerAddress) == true)
        {
          m_socket->Bind(local);
          m_socket->Connect (InetSocketAddress (Ipv4Address::ConvertFrom(m_peerAddress), m_peerPort));
        }
      else if (Ipv6Address::IsMatchingType(m_peerAddress) == true)
        {
          m_socket->Bind6();
          m_socket->Connect (Inet6SocketAddress (Ipv6Address::ConvertFrom(m_peerAddress), m_peerPort));
        }
    }

  if (nodeid == 2)
  {
    for (int i = 10; i < 20; i++)
    {
      AddCs(i, i);
    }
  }
  if (nodeid == 14 || nodeid == 27 || nodeid == 37 || nodeid == 45 || nodeid == 75 || nodeid == 90 || nodeid == 133 || nodeid == 134)
  {
    Simulator::Schedule (Seconds (0.0), &VehicleNetClient::fmRequestEven, this);
  }
  if (nodeid == 13 || nodeid == 30 || nodeid == 9 || nodeid == 41 || nodeid == 25 || nodeid == 53 || nodeid == 87 || nodeid == 77)
  {
    Simulator::Schedule (Seconds (0.0), &VehicleNetClient::fmRequestOdd, this);
  }
/*
  if (nodeid %2 == 1)
  {
    Simulator::Schedule (Seconds (0.0), &VehicleNetClient::fmRequestOdd, this);
  }
*/

/*
  if (nodeid == 22)
  {
    Simulator::Schedule (Seconds (5.121), &VehicleNetClient::fmRequestEven, this);
  }

  if (nodeid == 27)
  {
    Simulator::Schedule (Seconds (10.112), &VehicleNetClient::fmRequestEven, this);
  }
*/
  m_socket->SetRecvCallback (MakeCallback (&VehicleNetClient::HandleRead, this));
  m_socket->SetAllowBroadcast (true);
  ScheduleTransmit (Seconds (0.));
  Simulator::Schedule (Seconds (5.0), &VehicleNetClient::Advertise, this);
}

void 
VehicleNetClient::StopApplication ()
{
  NS_LOG_FUNCTION (this);

  if (m_socket != 0) 
    {
      m_socket->Close ();
      m_socket->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
      m_socket = 0;
    }

  Simulator::Cancel (m_sendEvent);
}

void 
VehicleNetClient::SetDataSize (uint32_t dataSize)
{
  NS_LOG_FUNCTION (this << dataSize);

  //
  // If the client is setting the echo packet data size this way, we infer
  // that she doesn't care about the contents of the packet at all, so 
  // neither will we.
  //
  delete [] m_data;
  m_data = 0;
  m_dataSize = 0;
  m_size = dataSize;
}

uint32_t 
VehicleNetClient::GetDataSize (void) const
{
  NS_LOG_FUNCTION (this);
  return m_size;
}

void 
VehicleNetClient::SetFill (std::string fill)
{
  NS_LOG_FUNCTION (this << fill);

  uint32_t dataSize = fill.size () + 1;

  if (dataSize != m_dataSize)
    {
      delete [] m_data;
      m_data = new uint8_t [dataSize];
      m_dataSize = dataSize;
    }

  memcpy (m_data, fill.c_str (), dataSize);

  //
  // Overwrite packet size attribute.
  //
  m_size = dataSize;
}

void 
VehicleNetClient::SetFill (uint8_t fill, uint32_t dataSize)
{
  NS_LOG_FUNCTION (this << fill << dataSize);
  if (dataSize != m_dataSize)
    {
      delete [] m_data;
      m_data = new uint8_t [dataSize];
      m_dataSize = dataSize;
    }

  memset (m_data, fill, dataSize);

  //
  // Overwrite packet size attribute.
  //
  m_size = dataSize;
}

void 
VehicleNetClient::SetFill (uint8_t *fill, uint32_t fillSize, uint32_t dataSize)
{
  NS_LOG_FUNCTION (this << fill << fillSize << dataSize);
  if (dataSize != m_dataSize)
    {
      delete [] m_data;
      m_data = new uint8_t [dataSize];
      m_dataSize = dataSize;
    }

  if (fillSize >= dataSize)
    {
      memcpy (m_data, fill, dataSize);
      m_size = dataSize;
      return;
    }

  //
  // Do all but the final fill.
  //
  uint32_t filled = 0;
  while (filled + fillSize < dataSize)
    {
      memcpy (&m_data[filled], fill, fillSize);
      filled += fillSize;
    }

  //
  // Last fill may be partial
  //
  memcpy (&m_data[filled], fill, dataSize - filled);

  //
  // Overwrite packet size attribute.
  //
  m_size = dataSize;
}

void 
VehicleNetClient::ScheduleTransmit (Time dt)
{
  NS_LOG_FUNCTION (this << dt);
  //m_sendEvent = Simulator::Schedule (dt, &VehicleNetClient::SendInterest, this);
}

void 
VehicleNetClient::Send (void)
{
  NS_LOG_FUNCTION (this);

  NS_ASSERT (m_sendEvent.IsExpired ());


  // instantiate a header.
  ClientHeader clientHeader;
  clientHeader.SetData (2);

  // instantiate a packet
  Ptr<Packet> p = Create<Packet> ();

  // and store my header into the packet.
  p->AddHeader (clientHeader);
  m_socket->Send (p);
  std::cout<<Simulator::Now() << " " << GetNode () -> GetId() << " Data Sent by Client"<<std::endl;
  ++m_sent;

  if (Ipv4Address::IsMatchingType (m_peerAddress))
    {
      NS_LOG_INFO ("At time " << Simulator::Now ().GetSeconds () << "s client sent " << m_size << " bytes to " <<
                   Ipv4Address::ConvertFrom (m_peerAddress) << " port " << m_peerPort);
    }
  else if (Ipv6Address::IsMatchingType (m_peerAddress))
    {
      NS_LOG_INFO ("At time " << Simulator::Now ().GetSeconds () << "s client sent " << m_size << " bytes to " <<
                   Ipv6Address::ConvertFrom (m_peerAddress) << " port " << m_peerPort);
    }

  if (m_sent < m_count) 
    {
      ScheduleTransmit (m_interval);
    }
}

void
VehicleNetClient::HandleRead (Ptr<Socket> socket)
{
  // type 1 = advertise, 2 = interest, 3 = data
  NS_LOG_FUNCTION (this << socket);
  Ptr<Packet> packet;
  Address from;
  while ((packet = socket->RecvFrom (from)))
    {
      ClientHeader destinationHeader;
      packet->RemoveHeader (destinationHeader);
      //std::cout<<Simulator::Now() << " " << GetNode () -> GetId ()<<" Client received type: "<<destinationHeader.GetData()<<std::endl;

      //Received Advertise update FIB
      if (destinationHeader.GetData () == 1.0) {
        ClientHeader count, name, locX, locY;
        packet->RemoveHeader (count);
        for (int k = 0; k < count.GetData(); k++)
        {
          packet->RemoveHeader (name);
          packet->RemoveHeader (locX);
          packet->RemoveHeader (locY);
          Vector pos (locX.GetData(), locY.GetData(), 0.);
          UpdateFib(name.GetData(), pos);
          //std::cout<<Simulator::Now() << " " << GetNode () -> GetId ()<<" received advertise: "<<name.GetData()<<"location: "<<locX.GetData()<< " , " <<locY.GetData()<<std::endl;
        }
      }
      else if (destinationHeader.GetData () == 2.0) 
      {
        ClientHeader name, requester;
        packet->RemoveHeader (name);
        packet->RemoveHeader (requester);
        //std::cout<<Simulator::Now() << " " << GetNode () -> GetId ()<<" received interest: "<<name.GetData()<<std::endl;
        RespondInterest (name.GetData (), requester.GetData());
      }
      else if (destinationHeader.GetData () == 3.0) 
      {
        ClientHeader name, data;
        packet->RemoveHeader (name);
        packet->RemoveHeader (data);
        //std::cout<<Simulator::Now() << " " << GetNode () -> GetId ()<<" received data: "<<name.GetData()<<std::endl;
        RespondData (name.GetData (), data.GetData());
      }
    }
}
ClientHeader::ClientHeader ()
{
  // we must provide a public default constructor, 
  // implicit or explicit, but never private.
}
ClientHeader::~ClientHeader ()
{
}

TypeId
ClientHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::ClientHeader")
    .SetParent<Header> ()
    .AddConstructor<ClientHeader> ()
  ;
  return tid;
}
TypeId
ClientHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
ClientHeader::Print (std::ostream &os) const
{
  // This method is invoked by the packet printing
  // routines to print the content of my header.
  //os << "data=" << m_data << std::endl;
  os << "data=" << m_data;
}
uint32_t
ClientHeader::GetSerializedSize (void) const
{
  // we reserve 2 bytes for our header.
  return 2;
}
void
ClientHeader::Serialize (Buffer::Iterator start) const
{
  // we can serialize two bytes at the start of the buffer.
  // we write them in network byte order.
  start.WriteHtonU16 (m_data);
}
uint32_t
ClientHeader::Deserialize (Buffer::Iterator start)
{
  // we can deserialize two bytes from the start of the buffer.
  // we read them in network byte order and store them
  // in host byte order.
  m_data = start.ReadNtohU16 ();

  // we return the number of bytes effectively read.
  return 2;
}

void 
ClientHeader::SetData (uint16_t data)
{
  m_data = data;
}
uint16_t 
ClientHeader::GetData (void) const
{
  return m_data;
}

} // Namespace ns3
